Dear reader,

there is not much to say about this model.
It is a quake 1 enemy model that clones the behavior of the original
ogre. You can use this model however you like.

To export to quake you have to scale the model up by 5.2
Rotate 90° and translate -24 on the Z-Axis.

For more info have a look at https://pnahratow.github.io/
