Dear reader,

there is not much to say about this model.
It is a quake 1 enemy model that clones the behavior of the original
ogre. You can rename the files to ogre.mdl and h_ogre.mdl to directly 
replace the ogre or integrate it however you see fit. 
You can use this model however you like.

For more info have a look at https://pnahratow.github.io/
