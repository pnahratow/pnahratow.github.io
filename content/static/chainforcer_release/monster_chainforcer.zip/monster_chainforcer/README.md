# monster_chainforcer

This is a custom quake 1 enemy model depicting a soldier type person wearing an enormous helmet and carrying a chaingun.

It generally fires the chaingun but in close ranges will headbutt and in medium far ranges might fire grenades. The generic behaviour is derived from the enforcer monster.

## Integration

To integrate the monster into your mod you need to

- Place `chainforcer.qc` into your quakec source directory
- Add `chainforcer.qc` to the end of `progs.src`
- Extend the `ClientObituary` function in `client.qc` to have a "killed by" text
- Extend the `SightSound` function in `ai.qc` to have the sight sound play (see `void() chnfcr_sight_sound` in `chainforcer.qc`)
- Extend your map editor entity definition like with the following FGD format line

```
@PointClass base(Monster) size(-16 -16 -24, 16 16 40) model({ "path": ":progs/chainforcer.mdl" }) = monster_chainforcer : "Chainforcer" []
```

There is a `progs.dat` included for testing. Here all soldier enemies are replaced. Start the game with `quake -game monster_chainforcer` to test.

## Licenses

- The quakec code is GPLv2 derived and therefore falls under the same license.
- All other included media assets are marked with CC0 1.0 and can be used freely (see https://creativecommons.org/publicdomain/zero/1.0/)

## Numbers

- 736 triangles
- 256x256px texture
- 105 animation frames
  - stand (7)
  - walk (16)
  - run (8)
  - gunfire (17)
  - death_a (14)
  - death_b (11)
  - pain_a (4)
  - pain_b (5)
  - pain_c (8)
  - grenade (6)
  - headbutt (8)
